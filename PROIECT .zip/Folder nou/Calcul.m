clear
clc

Gb = 80;
V = 120;
Xb = 0.0054;
Ag = 0.8;
tgmax = 40;
p1 = 0.006;
p2 = 0.024;
p3 = 7.59 * 10^-6;
n = 0.17;


A = [-(p1+Xb), -Gb, 0;
    0, -p2, p3;
    0, 0, -n];
B = [0; 0; 1/V];
C = [1, 0, 0];
P = [B, A*B, A*A*B];
det(P);


%polinom caracteristic
syms k1 k2 k3 s
A = [-(p1+Xb), -Gb, 0;
    0, -p2, p3;
    0, 0, -n];
B = [0; 0; 1/V];
K = [k1, k2, k3];

Cs = vpa(s * eye(3) - A + B * K);
det(Cs);

K3 = 4.152;
K2 = 13969.3;
K1 = -11.9488;

Kn = [K1 K2 K3];

Q = [C; C*A; C*A^2];
rank(Q);

Ke=[k1; k2; k3];
Cs =vpa(s*eye(3)-A+Ke*C);
det(Cs)

Kr = 1/(C * inv(B*Kn-A)*B);

Ke1 = 0.0346;
Ke2 = 0.00005755;
Ke3 = -1.11166;

